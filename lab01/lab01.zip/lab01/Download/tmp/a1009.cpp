#include <iostream>
#include <cstdio>

using namespace std;

char str[100][80];
int main()
{
    int i=0;
    while (~scanf("%s",str+i))
    {
        i++;
    }
    for(int j=i-1;j>=0;j--){
        if(j==i-1)
            printf("%s",str+j);
        else printf(" %s",str+j);
    }
    return 0;
}
