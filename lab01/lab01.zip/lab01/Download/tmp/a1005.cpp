#include <iostream>
#include <cstdio>
#include <algorithm>

int hash[10500];
void add(int num){
    if(num%2==0){
        num/=2;
    }
    else num=(num*3+1)/2;
    while (num!=1)
    {
        if(hash[num]==0){
            hash[num]=1;
        }
        if(num%2==0){
            num/=2;
        }
        else {
            num=num*3+1;
            num/=2;
        }
    }
    
}

bool cmp(int a,int b){
    return a>b;
}
int main()
{
    int n,num[105],ans[105]={0},cnt=0;
    std::cin>>n;
    for(int i=0;i<n;i++){
        std::cin>>num[i];
        add(num[i]);
    }
    for(int i=0;i<n;i++){
        if(hash[num[i]]==0){
            ans[cnt++]=num[i];
        }
    }
    std::sort(ans,ans+cnt,cmp);
    std::cout<<ans[0];
    for(int i=1;i<cnt;i++){
        std::cout<<" "<<ans[i];
    }
    return 0;
}
