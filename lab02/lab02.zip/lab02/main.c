#include "mytool1.h"
#include "mytool2.h"
int main(int argc,char **argv){
    mytool1_print("hello");
    mytool2_print("hello");
}