#include "mytool1.h"
#include "stdio.h"

void mytool1_print(char *print_str){
    printf("This is mytool1 print %s\n",print_str);
    printf("In mytool1\n");
    printf("In mytool1\n");
    printf("In mytool1\n");
    printf("In mytool1\n");
}
