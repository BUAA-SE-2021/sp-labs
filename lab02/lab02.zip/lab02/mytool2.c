#include "mytool2.h"
void mytool2_print(char *print_str){
    printf("This is mytool2 print %s\n",print_str);
    printf("In mytool2\n");
    printf("In mytool2\n");
    printf("In mytool2\n");
    printf("In mytool2\n");
    printf("In mytool2\n");
}