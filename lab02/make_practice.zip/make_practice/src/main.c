#include<stdio.h>
#include<fun1.h>
#include<fun2.h>
int main()
{
	printf("hello world\n");
	fun1();
	fun2();
	return 0;
}
