#include<stdio.h>
void fun2()
{
	printf("this is fun2\n");
}
