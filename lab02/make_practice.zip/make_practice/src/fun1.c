#include<stdio.h>
void fun1()
{
	printf("this is fun1\n");
}
