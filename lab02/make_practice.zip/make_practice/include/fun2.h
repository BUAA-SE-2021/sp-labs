void fun2();
