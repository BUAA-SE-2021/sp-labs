void dynamic_lib_call();
